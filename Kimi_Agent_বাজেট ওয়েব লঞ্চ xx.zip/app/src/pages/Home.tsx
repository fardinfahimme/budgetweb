import { useEffect, useState } from "react";
import Lenis from "lenis";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Preloader from "@/components/Preloader";
import Cursor from "@/components/Cursor";
import Navbar from "@/components/Navbar";
import Hero from "@/sections/Hero";
import Marquee from "@/sections/Marquee";
import Stats from "@/sections/Stats";
import Services from "@/sections/Services";
import Process from "@/sections/Process";
import Pricing from "@/sections/Pricing";
import Faq from "@/sections/Faq";
import Cta from "@/sections/Cta";
import Footer from "@/sections/Footer";

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const [started, setStarted] = useState(false);

  /* Lenis smooth scroll synced with GSAP ticker */
  useEffect(() => {
    const lenis = new Lenis({
      lerp: 0.1,
      wheelMultiplier: 0.9,
      touchMultiplier: 1.4,
    });
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);

    /* anchor buttons work through lenis */
    const onClick = (e: Event) => {
      const t = (e.target as HTMLElement).closest("[data-scroll-to]") as HTMLElement | null;
      if (t) lenis.scrollTo(t.dataset.scrollTo!);
    };
    document.addEventListener("click", onClick);

    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
      document.removeEventListener("click", onClick);
    };
  }, []);

  return (
    <div className="noise relative min-h-screen bg-[#07040d] text-[#f4f2fa]">
      <Preloader onDone={() => setStarted(true)} />
      <Cursor />
      <Navbar />
      <main>
        <Hero started={started} />
        <Marquee />
        <Stats />
        <Services />
        <Process />
        <Pricing />
        <Faq />
        <Cta />
      </main>
      <Footer />
    </div>
  );
}
