import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { services, links } from "@/config";
import Reveal from "@/components/Reveal";
import { ArrowIcon } from "@/components/Navbar";

gsap.registerPlugin(ScrollTrigger);

/**
 * Sticky stacking service cards — each card pins with an offset,
 * previous cards scale down + blur as the stack builds.
 */
export default function Services() {
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray<HTMLElement>(".svc-card");
      cards.forEach((card, i) => {
        if (i === cards.length - 1) return;
        gsap.to(card, {
          scale: 0.92,
          filter: "blur(6px)",
          opacity: 0.55,
          transformOrigin: "center top",
          ease: "none",
          scrollTrigger: {
            trigger: cards[i + 1],
            start: "top 80%",
            end: "top 15%",
            scrub: true,
          },
        });
      });
    }, wrapRef);
    return () => ctx.revert();
  }, []);

  return (
    <section id="services" className="relative py-24 md:py-36">
      <div className="orb left-[-200px] top-1/4 h-[500px] w-[500px] bg-[#7c3aed]/15" />
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        <Reveal className="mb-4 flex items-center gap-3">
          <span className="h-px w-10 bg-[#9680ff]" />
          <span className="font-mono2 text-[11px] uppercase tracking-[0.32em] text-[#9680ff]">{services.eyebrow}</span>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="font-display max-w-3xl text-4xl font-bold leading-[1.05] tracking-tight text-white md:text-6xl">
            {services.title}
          </h2>
        </Reveal>

        <div ref={wrapRef} className="mt-16 md:mt-24">
          {services.items.map((s, i) => (
            <div
              key={s.index}
              className="svc-card sticky mb-8 md:mb-12"
              style={{ top: `calc(96px + ${i * 34}px)` }}
            >
              <div className="group relative overflow-hidden rounded-3xl border border-white/[0.08] bg-gradient-to-br from-[#120a20] to-[#0a0514] p-8 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.7)] md:p-14">
                {/* hover glow */}
                <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-[#7c3aed]/20 opacity-0 blur-[80px] transition-opacity duration-700 group-hover:opacity-100" />
                <div className="relative flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
                  <div className="max-w-2xl">
                    <span className="font-mono2 text-sm tracking-[0.3em] text-[#7c3aed]">{s.index}</span>
                    <h3 className="font-display mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
                      {s.title}
                    </h3>
                    <p className="mt-5 leading-relaxed text-[#b6afca] md:text-lg">{s.desc}</p>
                    <div className="mt-7 flex flex-wrap gap-2.5">
                      {s.tags.map((t) => (
                        <span
                          key={t}
                          className="rounded-full border border-[#9680ff]/25 bg-[#9680ff]/[0.07] px-4 py-1.5 font-mono2 text-[11px] uppercase tracking-[0.14em] text-[#c4b5fd]"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                  <a
                    href={links.messenger}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex shrink-0 items-center gap-2 self-start rounded-full border border-white/15 px-6 py-3 text-sm font-medium text-[#d9d4e8] transition-all duration-300 hover:border-[#9680ff]/70 hover:bg-[#9680ff]/10 hover:text-white md:self-auto"
                  >
                    Order this
                    <ArrowIcon />
                  </a>
                </div>
                {/* big ghost number */}
                <span className="font-display pointer-events-none absolute -bottom-10 right-6 select-none text-[10rem] font-extrabold leading-none text-white/[0.03] md:text-[14rem]">
                  {s.index}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
