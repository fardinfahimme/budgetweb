import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { process } from "@/config";
import Reveal from "@/components/Reveal";

gsap.registerPlugin(ScrollTrigger);

/** Process timeline — a growing line + staggered step reveals */
export default function Process() {
  const lineRef = useRef<HTMLDivElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        lineRef.current,
        { scaleY: 0 },
        {
          scaleY: 1,
          transformOrigin: "top",
          ease: "none",
          scrollTrigger: {
            trigger: wrapRef.current,
            start: "top 70%",
            end: "bottom 60%",
            scrub: true,
          },
        }
      );
    }, wrapRef);
    return () => ctx.revert();
  }, []);

  return (
    <section id="process" className="relative py-24 md:py-36">
      <div className="orb right-[-180px] top-0 h-[460px] w-[460px] bg-[#a855f7]/12" />
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        <Reveal className="mb-4 flex items-center gap-3">
          <span className="h-px w-10 bg-[#9680ff]" />
          <span className="font-mono2 text-[11px] uppercase tracking-[0.32em] text-[#9680ff]">{process.eyebrow}</span>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="font-display max-w-3xl text-4xl font-bold leading-[1.05] tracking-tight text-white md:text-6xl">
            {process.title}
          </h2>
        </Reveal>

        <div ref={wrapRef} className="relative mt-16 md:mt-24">
          {/* timeline line */}
          <div className="absolute bottom-0 left-[22px] top-0 w-px bg-white/[0.07] md:left-1/2" />
          <div
            ref={lineRef}
            className="absolute bottom-0 left-[22px] top-0 w-px bg-gradient-to-b from-[#9680ff] to-[#a855f7] shadow-[0_0_12px_rgba(150,128,255,0.6)] md:left-1/2"
          />

          <div className="flex flex-col gap-14 md:gap-24">
            {process.steps.map((st, i) => (
              <div
                key={st.n}
                className={`relative flex md:w-1/2 ${
                  i % 2 === 0 ? "md:pr-16" : "md:ml-auto md:pl-16"
                } pl-16 md:pl-0 ${i % 2 === 1 ? "md:pl-16" : ""}`}
              >
                {/* node */}
                <span
                  className={`absolute left-[22px] top-2 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-[#9680ff] bg-[#07040d] shadow-[0_0_14px_rgba(150,128,255,0.8)] md:top-3 ${
                    i % 2 === 0 ? "md:left-full" : "md:left-0"
                  }`}
                />
                <Reveal delay={0.05}>
                  <span className="font-mono2 text-sm tracking-[0.3em] text-[#7c3aed]">{st.n}</span>
                  <h3 className="font-display mt-3 text-2xl font-bold tracking-tight text-white md:text-4xl">
                    {st.title}
                  </h3>
                  <p className="mt-4 max-w-md leading-relaxed text-[#b6afca]">{st.desc}</p>
                </Reveal>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
