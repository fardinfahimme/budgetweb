import { useState } from "react";
import { faq } from "@/config";
import Reveal from "@/components/Reveal";

export default function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 md:py-36">
      <div className="mx-auto max-w-4xl px-5 md:px-10">
        <Reveal className="mb-4 flex items-center gap-3">
          <span className="h-px w-10 bg-[#9680ff]" />
          <span className="font-mono2 text-[11px] uppercase tracking-[0.32em] text-[#9680ff]">{faq.eyebrow}</span>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="font-display text-4xl font-bold leading-[1.05] tracking-tight text-white md:text-6xl">
            {faq.title}
          </h2>
        </Reveal>

        <div className="mt-14">
          {faq.items.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={i} delay={i * 0.06}>
                <div className="border-b border-white/[0.08]">
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-6 py-6 text-left md:py-7"
                    aria-expanded={isOpen}
                  >
                    <span
                      className={`font-display text-lg font-semibold tracking-tight transition-colors duration-300 md:text-2xl ${
                        isOpen ? "text-[#c4b5fd]" : "text-white"
                      }`}
                    >
                      {f.q}
                    </span>
                    <span
                      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border transition-all duration-500 ${
                        isOpen
                          ? "rotate-45 border-[#9680ff]/60 bg-[#9680ff]/10 text-[#c4b5fd]"
                          : "border-white/15 text-[#8f88a3]"
                      }`}
                    >
                      <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                        <path d="M12 5v14M5 12h14" />
                      </svg>
                    </span>
                  </button>
                  <div
                    className="grid transition-[grid-template-rows] duration-500"
                    style={{ gridTemplateRows: isOpen ? "1fr" : "0fr", transitionTimingFunction: "cubic-bezier(0.22,1,0.36,1)" }}
                  >
                    <div className="overflow-hidden">
                      <p className="max-w-2xl pb-7 leading-relaxed text-[#b6afca]">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
