import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { cta, links } from "@/config";
import Magnetic from "@/components/Magnetic";
import Reveal from "@/components/Reveal";
import { ArrowIcon } from "@/components/Navbar";

gsap.registerPlugin(ScrollTrigger);

/** Big closing CTA — giant words slide in from opposite sides on scroll */
export default function Cta() {
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".cta-line-1",
        { xPercent: -12, opacity: 0 },
        {
          xPercent: 0,
          opacity: 1,
          ease: "power3.out",
          scrollTrigger: { trigger: wrapRef.current, start: "top 85%", end: "top 35%", scrub: 1 },
        }
      );
      gsap.fromTo(
        ".cta-line-2",
        { xPercent: 12, opacity: 0 },
        {
          xPercent: 0,
          opacity: 1,
          ease: "power3.out",
          scrollTrigger: { trigger: wrapRef.current, start: "top 85%", end: "top 35%", scrub: 1 },
        }
      );
    }, wrapRef);
    return () => ctx.revert();
  }, []);

  return (
    <section className="relative overflow-hidden py-28 md:py-44">
      <div className="orb left-1/2 top-1/2 h-[520px] w-[820px] -translate-x-1/2 -translate-y-1/2 bg-[#7c3aed]/22" />
      <div ref={wrapRef} className="relative mx-auto max-w-7xl px-5 text-center md:px-10">
        <h2 className="font-display font-extrabold leading-[0.95] tracking-tight">
          <span className="cta-line-1 block text-[15vw] text-white md:text-[9rem]">{cta.titleLine1}</span>
          <span className="cta-line-2 text-grad block text-[15vw] md:text-[9rem]">{cta.titleLine2}</span>
        </h2>
        <Reveal delay={0.1}>
          <p className="mx-auto mt-8 max-w-xl text-[#b6afca] md:text-lg">{cta.sub}</p>
        </Reveal>
        <Reveal delay={0.2}>
          <div className="mt-12">
            <Magnetic strength={0.4}>
              <a
                href={links.messenger}
                target="_blank"
                rel="noreferrer"
                className="btn-cool inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#a855f7] px-10 py-5 text-lg font-semibold text-white shadow-[0_15px_50px_-10px_rgba(124,58,237,0.6)] transition-transform duration-300 active:scale-95"
              >
                {/* FB icon */}
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047v-2.66c0-3.025 1.792-4.697 4.533-4.697 1.313 0 2.686.236 2.686.236v2.971H15.83c-1.491 0-1.956.93-1.956 1.886v2.264h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z" />
                </svg>
                {cta.button}
                <ArrowIcon className="h-5 w-5" />
              </a>
            </Magnetic>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
