import { site, nav, links, footer } from "@/config";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/[0.07] bg-[#050309]">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-10 md:py-20">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <img src={site.logo} alt={site.logoAlt} className="h-12 w-auto" />
            <p className="mt-6 text-sm leading-relaxed text-[#8f88a3]">{footer.blurb}</p>
          </div>

          <div className="flex gap-16 md:gap-24">
            <div>
              <h4 className="font-mono2 text-[11px] uppercase tracking-[0.28em] text-[#9680ff]">Explore</h4>
              <ul className="mt-5 flex flex-col gap-3">
                {nav.map((n) => (
                  <li key={n.href}>
                    <button
                      onClick={() => document.querySelector(n.href)?.scrollIntoView({ behavior: "smooth" })}
                      className="u-link text-sm text-[#c9c3d9] transition-colors hover:text-white"
                    >
                      {n.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-mono2 text-[11px] uppercase tracking-[0.28em] text-[#9680ff]">Connect</h4>
              <ul className="mt-5 flex flex-col gap-3">
                <li>
                  <a href={links.facebook} target="_blank" rel="noreferrer" className="u-link text-sm text-[#c9c3d9] transition-colors hover:text-white">
                    Facebook Page
                  </a>
                </li>
                <li>
                  <a href={links.messenger} target="_blank" rel="noreferrer" className="u-link text-sm text-[#c9c3d9] transition-colors hover:text-white">
                    Messenger
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* credit bar */}
        <div className="mt-16 flex flex-col items-center justify-between gap-5 border-t border-white/[0.06] pt-8 md:flex-row">
          <p className="text-xs text-[#6f6885]">
            © {year} {site.name}. {footer.copyright}
          </p>
          <p className="text-sm tracking-wide text-[#8f88a3]">
            {footer.creditLabel}{" "}
            <a
              href={links.credit}
              target="_blank"
              rel="noreferrer"
              className="font-display text-grad font-bold transition-opacity duration-300 hover:opacity-80"
            >
              {site.name}
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
