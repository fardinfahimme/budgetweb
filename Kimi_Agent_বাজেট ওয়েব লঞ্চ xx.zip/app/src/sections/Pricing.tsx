import { pricing, links } from "@/config";
import Reveal from "@/components/Reveal";
import Magnetic from "@/components/Magnetic";
import { ArrowIcon } from "@/components/Navbar";

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-24 md:py-36">
      <div className="orb left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 bg-[#7c3aed]/14" />
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        <Reveal className="mb-4 flex items-center justify-center gap-3">
          <span className="h-px w-10 bg-[#9680ff]" />
          <span className="font-mono2 text-[11px] uppercase tracking-[0.32em] text-[#9680ff]">{pricing.eyebrow}</span>
          <span className="h-px w-10 bg-[#9680ff]" />
        </Reveal>
        <Reveal delay={0.08}>
          <h2 className="font-display mx-auto max-w-3xl text-center text-4xl font-bold leading-[1.05] tracking-tight text-white md:text-6xl">
            {pricing.title}
          </h2>
        </Reveal>
        <Reveal delay={0.14}>
          <p className="mt-5 text-center text-[#8f88a3]">{pricing.note}</p>
        </Reveal>

        <div className="mt-16 grid gap-6 md:mt-20 lg:grid-cols-3 lg:items-stretch">
          {pricing.tiers.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.12} className="h-full">
              <div
                className={`relative flex h-full flex-col rounded-3xl p-8 transition-transform duration-500 md:p-10 ${
                  t.featured
                    ? "border border-[#9680ff]/40 bg-gradient-to-b from-[#160b2a] to-[#0b0616] shadow-[0_30px_90px_-20px_rgba(124,58,237,0.45)] lg:-translate-y-4"
                    : "border border-white/[0.08] bg-[#0c0716]/80 hover:border-white/[0.16]"
                }`}
              >
                {t.featured && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#a855f7] px-4 py-1 font-mono2 text-[10px] uppercase tracking-[0.2em] text-white">
                    Most popular
                  </span>
                )}
                <h3 className="font-mono2 text-sm uppercase tracking-[0.28em] text-[#9680ff]">{t.name}</h3>
                <div className="mt-5 flex items-end gap-2">
                  <span className="font-display text-5xl font-extrabold tracking-tight text-white md:text-6xl">
                    {t.price}
                  </span>
                  <span className="pb-2 text-sm text-[#8f88a3]">{t.unit}</span>
                </div>
                <p className="mt-3 text-sm text-[#b6afca]">{t.desc}</p>
                <ul className="mt-8 flex flex-1 flex-col gap-3.5">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm text-[#d9d4e8]">
                      <svg className="mt-0.5 h-4 w-4 shrink-0 text-[#9680ff]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 6L9 17l-5-5" />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
                <Magnetic strength={0.2} className="mt-9 w-full">
                  <a
                    href={links.messenger}
                    target="_blank"
                    rel="noreferrer"
                    className={`flex w-full items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold transition-all duration-300 active:scale-95 ${
                      t.featured
                        ? "btn-cool bg-gradient-to-r from-[#7c3aed] to-[#a855f7] text-white"
                        : "border border-white/15 text-[#d9d4e8] hover:border-[#9680ff]/60 hover:bg-[#9680ff]/10 hover:text-white"
                    }`}
                  >
                    {t.cta}
                    <ArrowIcon />
                  </a>
                </Magnetic>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-12 text-center text-sm text-[#8f88a3]">
            {pricing.custom}{" "}
            <a href={links.messenger} target="_blank" rel="noreferrer" className="u-link font-medium text-[#c4b5fd]">
              Message us
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}
