import { useEffect, useRef } from "react";
import { hero, links } from "@/config";
import Magnetic from "@/components/Magnetic";
import { ArrowIcon } from "@/components/Navbar";

/** Split a string into per-char reveal spans */
function SplitLine({ text, gradient, baseDelay }: { text: string; gradient: boolean; baseDelay: number }) {
  return (
    <span className="block whitespace-nowrap">
      {text.split("").map((ch, i) => (
        <span key={i} className="char-wrap">
          <span
            className={`char hero-char ${gradient ? "text-grad" : ""}`}
            style={{ transitionDelay: `${baseDelay + i * 0.028}s` }}
          >
            {ch === " " ? "\u00A0" : ch}
          </span>
        </span>
      ))}
    </span>
  );
}

export default function Hero({ started }: { started: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  /* char reveal trigger */
  useEffect(() => {
    if (!started) return;
    const chars = sectionRef.current?.querySelectorAll<HTMLElement>(".hero-char");
    chars?.forEach((c) => {
      c.style.transition = "transform 0.9s cubic-bezier(0.22, 1, 0.36, 1)";
      requestAnimationFrame(() => {
        c.style.transform = "translateY(0) rotate(0deg)";
      });
    });
    const fades = sectionRef.current?.querySelectorAll<HTMLElement>(".hero-fade");
    fades?.forEach((f) => f.classList.add("in"));
  }, [started]);

  /* interactive dot-grid canvas */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let w = 0, h = 0, raf = 0;
    let mx = -9999, my = -9999;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const r = canvas.parentElement!.getBoundingClientRect();
      w = r.width;
      h = r.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const onMove = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      mx = e.clientX - r.left;
      my = e.clientY - r.top;
    };
    const onLeave = () => {
      mx = -9999;
      my = -9999;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    window.addEventListener("pointerleave", onLeave);

    const GAP = 34;
    let t = 0;
    const draw = () => {
      t += 0.008;
      ctx.clearRect(0, 0, w, h);
      const cols = Math.ceil(w / GAP) + 1;
      const rows = Math.ceil(h / GAP) + 1;
      for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
          const x = i * GAP;
          const y = j * GAP;
          const wave = Math.sin(t + i * 0.35 + j * 0.25) * 0.5 + 0.5;
          const dx = x - mx;
          const dy = y - my;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const influence = Math.max(0, 1 - dist / 180);
          const r = 0.8 + wave * 0.7 + influence * 2.6;
          const alpha = 0.05 + wave * 0.06 + influence * 0.65;
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.fillStyle =
            influence > 0.02
              ? `rgba(150, 128, 255, ${alpha})`
              : `rgba(180, 165, 220, ${alpha})`;
          ctx.fill();
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerleave", onLeave);
    };
  }, []);

  /* subtle parallax on scroll */
  useEffect(() => {
    const onScroll = () => {
      const el = innerRef.current;
      if (!el) return;
      const y = window.scrollY;
      if (y < window.innerHeight) {
        el.style.transform = `translateY(${y * 0.22}px)`;
        el.style.opacity = String(1 - y / (window.innerHeight * 0.9));
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  let delayAcc = 0.15;

  return (
    <section id="top" ref={sectionRef} className="relative flex min-h-[100svh] items-center overflow-hidden">
      {/* glow orbs */}
      <div className="orb -left-40 -top-40 h-[560px] w-[560px] bg-[#7c3aed]/30" />
      <div className="orb -right-52 top-1/3 h-[620px] w-[620px] bg-[#a855f7]/20" />
      <div className="orb bottom-[-220px] left-1/3 h-[480px] w-[480px] bg-[#4c1d95]/35" />

      {/* dot canvas */}
      <div className="absolute inset-0">
        <canvas ref={canvasRef} className="block" />
      </div>

      {/* fade to bg at bottom */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#07040d] to-transparent" />

      <div ref={innerRef} className="relative z-10 mx-auto w-full max-w-7xl px-5 pb-24 pt-36 md:px-10 md:pt-40">
        <div className="hero-fade rv mb-8 flex items-center gap-3" style={{ ["--rv-delay" as string]: "0.05s" }}>
          <span className="h-px w-10 bg-[#9680ff]" />
          <span className="font-mono2 text-[11px] uppercase tracking-[0.32em] text-[#9680ff]">
            {hero.eyebrow}
          </span>
        </div>

        <h1 className="font-display text-[10.8vw] font-extrabold leading-[0.98] tracking-tight text-white sm:text-[10vw] lg:text-[7.6rem] xl:text-[8.6rem]">
          {hero.lines.map((l, i) => {
            const d = delayAcc;
            delayAcc += 0.12 + l.text.length * 0.028;
            return <SplitLine key={i} text={l.text} gradient={l.gradient} baseDelay={d} />;
          })}
        </h1>

        <p
          className="hero-fade rv mt-9 max-w-xl text-base leading-relaxed text-[#b6afca] md:text-lg"
          style={{ ["--rv-delay" as string]: `${delayAcc + 0.15}s` }}
        >
          {hero.sub}
        </p>

        <div
          className="hero-fade rv mt-11 flex flex-wrap items-center gap-4"
          style={{ ["--rv-delay" as string]: `${delayAcc + 0.3}s` }}
        >
          <Magnetic strength={0.35}>
            <a
              href={links.messenger}
              target="_blank"
              rel="noreferrer"
              className="btn-cool inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#a855f7] px-8 py-4 text-base font-semibold text-white shadow-[0_10px_40px_-8px_rgba(124,58,237,0.55)] transition-transform duration-300 active:scale-95"
            >
              {hero.primaryCta}
              <ArrowIcon />
            </a>
          </Magnetic>
          <Magnetic strength={0.25}>
            <button
              onClick={() => document.querySelector("#pricing")?.scrollIntoView({ behavior: "smooth" })}
              className="inline-flex items-center gap-2 rounded-full border border-white/15 px-8 py-4 text-base font-medium text-[#d9d4e8] transition-colors duration-300 hover:border-[#9680ff]/60 hover:text-white"
            >
              {hero.secondaryCta}
            </button>
          </Magnetic>
        </div>

        <div
          className="hero-fade rv mt-14 flex flex-wrap gap-x-8 gap-y-3"
          style={{ ["--rv-delay" as string]: `${delayAcc + 0.45}s` }}
        >
          {hero.badges.map((b) => (
            <div key={b} className="flex items-center gap-2.5 text-sm text-[#8f88a3]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#9680ff] shadow-[0_0_8px_#9680ff]" />
              {b}
            </div>
          ))}
        </div>
      </div>

      {/* scroll hint */}
      <div className="hero-fade rv absolute bottom-8 left-1/2 z-10 -translate-x-1/2" style={{ ["--rv-delay" as string]: "1.4s" }}>
        <div className="flex h-12 w-7 items-start justify-center rounded-full border border-white/15 p-2">
          <div className="h-2 w-1 animate-bounce rounded-full bg-[#9680ff]" />
        </div>
      </div>
    </section>
  );
}
