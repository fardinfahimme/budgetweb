import { marqueeItems } from "@/config";

/** Dual-direction marquee strip with outlined + filled word rhythm */
export default function Marquee() {
  const row = (outline: boolean) => (
    <div className="flex shrink-0 items-center">
      {marqueeItems.map((m, i) => (
        <span key={i} className="flex items-center">
          <span
            className={`font-display px-6 text-2xl font-bold tracking-tight md:px-10 md:text-4xl ${
              outline ? "text-transparent [-webkit-text-stroke:1px_rgba(150,128,255,0.5)]" : "text-white/90"
            }`}
          >
            {m}
          </span>
          <span className="text-[#7c3aed]">✦</span>
        </span>
      ))}
    </div>
  );

  return (
    <section className="relative border-y border-white/[0.07] bg-[#0a0514]/60 py-7 md:py-9" aria-hidden>
      <div className="marquee-reverse flex overflow-hidden" style={{ ["--marquee-dur" as string]: "36s" }}>
        <div className="marquee-track flex">
          {row(true)}
          {row(true)}
        </div>
      </div>
      <div className="mt-4 flex overflow-hidden" style={{ ["--marquee-dur" as string]: "30s" }}>
        <div className="marquee-track flex">
          {row(false)}
          {row(false)}
        </div>
      </div>
    </section>
  );
}
