import { useEffect, useRef, useState } from "react";
import { stats } from "@/config";
import Reveal from "@/components/Reveal";

function Counter({ value, suffix, run }: { value: number; suffix: string; run: boolean }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!run) return;
    let raf: number;
    const start = performance.now();
    const dur = 1600;
    const tick = (now: number) => {
      const t = Math.min((now - start) / dur, 1);
      setN(Math.round((1 - Math.pow(1 - t, 3)) * value));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [run, value]);
  return (
    <span className="tabular-nums">
      {n}
      {suffix}
    </span>
  );
}

export default function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const [run, setRun] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (e) => {
        if (e[0].isIntersecting) {
          setRun(true);
          io.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        <div ref={ref} className="grid grid-cols-2 gap-y-12 lg:grid-cols-4">
          {stats.map((s, i) => (
            <Reveal key={s.label} delay={i * 0.1} className="flex flex-col items-center gap-2 text-center">
              <span className="font-display text-5xl font-extrabold tracking-tight text-white md:text-6xl">
                <span className="text-grad">
                  <Counter value={s.value} suffix={s.suffix} run={run} />
                </span>
              </span>
              <span className="font-mono2 text-[11px] uppercase tracking-[0.24em] text-[#8f88a3]">{s.label}</span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
