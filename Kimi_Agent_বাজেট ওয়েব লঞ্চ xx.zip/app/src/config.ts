/**
 * ============================================================
 *  BUDGET WEB — SITE CONTENT CONFIG
 * ============================================================
 *  👉 এই ফাইলের ভেতরের লেখা, লিংক, প্রাইস, লোগো — সবকিছু
 *     এখান থেকে বদলালেই পুরো ওয়েবসাইটে বদলে যাবে।
 *     কোডের অন্য কোথাও ছোঁয়ার দরকার নেই।
 *
 *  👉 লোগো বদলাতে:  public/logo.png  ফাইলটা রিপ্লেস করো
 *     (একই নাম রেখে), অথবা নিচের logo path বদলে দাও।
 * ============================================================
 */

export const site = {
  name: "Budget Web",
  tagline: "Premium websites. Honest prices.",
  logo: "/logo.png", // ← লোগো এখানে বদলাও
  logoAlt: "Budget Web logo",
};

export const links = {
  // 👉 অর্ডার / মেসেজ লিংক
  messenger: "https://m.me/61594768599864", // সরাসরি Messenger চ্যাট
  facebook: "https://www.facebook.com/profile.php?id=61594768599864", // FB পেজ
  // 👉 ফুটারে "Made by Budget Web" এ ক্লিক করলে যে লিংকে যাবে
  credit: "https://budgetwebofficial.netlify.app/",
};

export const nav = [
  { label: "Services", href: "#services" },
  { label: "Process", href: "#process" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
];

export const hero = {
  eyebrow: "Web Design & Development Studio",
  // headline লাইনগুলো — "gradient: true" ওয়ালা অংশ বেগুনি গ্র্যাডিয়েন্ট হবে
  lines: [
    { text: "WORLD-CLASS", gradient: false },
    { text: "WEBSITES,", gradient: false },
    { text: "BUDGET PRICES.", gradient: true },
  ],
  sub: "We design and build fast, modern, international-standard websites for startups, creators and businesses — then take them live for you. Premium quality, without the premium invoice.",
  primaryCta: "Start Your Project",
  secondaryCta: "See Pricing",
  badges: ["Free live deployment", "Delivery in days", "Support after launch"],
};

export const marqueeItems = [
  "WEB DESIGN",
  "DEVELOPMENT",
  "E-COMMERCE",
  "LANDING PAGES",
  "SEO SETUP",
  "BRANDING",
  "REDESIGN",
  "MAINTENANCE",
];

export const stats = [
  { value: 40, suffix: "+", label: "Projects delivered" },
  { value: 12, suffix: "+", label: "Countries served" },
  { value: 98, suffix: "%", label: "Client satisfaction" },
  { value: 24, suffix: "/7", label: "Support availability" },
];

export const services = {
  eyebrow: "What we do",
  title: "Everything your business needs online.",
  items: [
    {
      index: "01",
      title: "Business Websites",
      desc: "A fast, elegant website that makes your company look established from day one — company profiles, service showcases and corporate sites built to convert visitors into clients.",
      tags: ["Company Profile", "Corporate", "CMS-ready"],
    },
    {
      index: "02",
      title: "E-Commerce Stores",
      desc: "Complete online stores with product pages, cart, checkout and order management — designed to feel premium and engineered to sell on every device.",
      tags: ["Online Store", "Payments", "Product Pages"],
    },
    {
      index: "03",
      title: "Landing Pages",
      desc: "High-converting landing pages for campaigns, product launches and personal brands — sharp copy structure, bold visuals, one clear call to action.",
      tags: ["Campaigns", "Launches", "Portfolios"],
    },
    {
      index: "04",
      title: "Redesign & Care",
      desc: "Already have a website? We rebuild it to international standards and keep it healthy — updates, speed optimization, backups and ongoing support.",
      tags: ["Redesign", "Speed Boost", "Maintenance"],
    },
  ],
};

export const process = {
  eyebrow: "How it works",
  title: "From message to live website — in four steps.",
  steps: [
    {
      n: "01",
      title: "Message us",
      desc: "Send a message on Facebook with your idea. No forms, no waiting — we reply fast and discuss what you need.",
    },
    {
      n: "02",
      title: "We design",
      desc: "Within days you get a modern design preview. We refine it together until it feels exactly right.",
    },
    {
      n: "03",
      title: "We build",
      desc: "Your site is developed with clean, fast code — pixel-perfect on mobile, tablet and desktop.",
    },
    {
      n: "04",
      title: "We go live",
      desc: "We deploy your website live on the internet for you — domain setup, hosting, everything handled.",
    },
  ],
};

export const pricing = {
  eyebrow: "Pricing",
  title: "Premium quality. Prices that make sense.",
  note: "Every package includes free deployment — we take your site live for you.",
  tiers: [
    {
      name: "Starter",
      price: "$49",
      unit: "one-time",
      desc: "Perfect for personal brands and small launches.",
      features: [
        "1-page modern website",
        "Mobile + desktop responsive",
        "Contact / social links",
        "Free live deployment",
        "Delivery in 3 days",
      ],
      featured: false,
      cta: "Order Starter",
    },
    {
      name: "Business",
      price: "$99",
      unit: "one-time",
      desc: "For businesses that need to look world-class.",
      features: [
        "Up to 5 pages",
        "Premium animations & design",
        "SEO basic setup",
        "WhatsApp / FB integration",
        "Free live deployment",
        "1 month free support",
      ],
      featured: true,
      cta: "Order Business",
    },
    {
      name: "Premium",
      price: "$199",
      unit: "one-time",
      desc: "Full-scale sites, stores and custom needs.",
      features: [
        "Unlimited pages",
        "E-commerce / custom features",
        "Advanced animations",
        "Speed optimization",
        "Free live deployment",
        "3 months free support",
      ],
      featured: false,
      cta: "Order Premium",
    },
  ],
  custom: "Need something custom? Message us — we'll quote within hours.",
};

export const faq = {
  eyebrow: "FAQ",
  title: "Questions, answered.",
  items: [
    {
      q: "How do I place an order?",
      a: "Simply click any order button on this page — it opens our Facebook page where you can message us directly. We discuss your needs, confirm the price, and start working.",
    },
    {
      q: "How can you offer international quality at low prices?",
      a: "We keep our team lean, work fully remote, and use a battle-tested modern tech stack. No office rent, no middlemen — so you pay for the work, not our overhead.",
    },
    {
      q: "Do you also make the website live?",
      a: "Yes. Deployment is included in every package. We publish your site on fast, reliable hosting and hand you the live link — you don't touch any technical setup.",
    },
    {
      q: "Can you redesign my existing website?",
      a: "Absolutely. Send us your current site link on Facebook and we'll rebuild it to modern, international standards — usually faster and cheaper than building from scratch.",
    },
    {
      q: "What if I need changes after delivery?",
      a: "Every package includes a free support period. Small text and image changes during that time are free — just message us.",
    },
    {
      q: "How long does a website take?",
      a: "A landing page typically takes 2–3 days, business sites 5–7 days, and larger stores 10–14 days. We confirm an exact timeline before starting.",
    },
  ],
};

export const cta = {
  titleLine1: "LET'S BUILD",
  titleLine2: "YOURS.",
  sub: "One message is all it takes. Tell us your idea — we'll handle design, development and going live.",
  button: "Message Us on Facebook",
};

export const footer = {
  blurb: "An independent web studio building international-standard websites at prices anyone can afford. Designed, developed and deployed for you.",
  creditLabel: "Made by",
  copyright: "All rights reserved.",
};
