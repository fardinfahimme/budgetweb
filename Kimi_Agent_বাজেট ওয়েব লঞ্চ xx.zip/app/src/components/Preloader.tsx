import { useEffect, useRef, useState } from "react";
import { site } from "@/config";

/**
 * Preloader: logo + tabular-numeral percentage counter,
 * then a circular clip-path mask collapses to reveal the page.
 */
export default function Preloader({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [closing, setClosing] = useState(false);
  const [gone, setGone] = useState(false);
  const doneRef = useRef(false);

  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const duration = 1400;

    const tick = (now: number) => {
      const t = Math.min((now - start) / duration, 1);
      // ease-out quart
      const eased = 1 - Math.pow(1 - t, 4);
      setProgress(Math.round(eased * 100));
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else if (!doneRef.current) {
        doneRef.current = true;
        setTimeout(() => {
          setClosing(true);
          setTimeout(() => {
            setGone(true);
            onDone();
          }, 950);
        }, 250);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (gone) return null;

  return (
    <div
      className={`preloader-mask ${closing ? "closing" : ""} fixed inset-0 z-[300] flex flex-col items-center justify-center bg-[#07040d]`}
      aria-hidden
    >
      {/* ambient glow */}
      <div className="orb left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 bg-[#7c3aed]/25" />
      <img
        src={site.logo}
        alt={site.logoAlt}
        className="relative w-40 md:w-56 drop-shadow-[0_0_35px_rgba(168,85,247,0.45)]"
        style={{ animation: "preloader-pulse 1.6s ease-in-out infinite" }}
      />
      <div className="relative mt-10 flex w-56 flex-col items-center gap-3 md:w-72">
        <div className="h-px w-full overflow-hidden bg-white/10">
          <div
            className="h-full bg-gradient-to-r from-[#9680ff] to-[#a855f7] transition-[width] duration-100"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="font-mono2 text-xs tracking-[0.3em] text-[#9c95b0] tabular-nums">
          {String(progress).padStart(3, "0")}%
        </div>
      </div>
      <style>{`
        @keyframes preloader-pulse {
          0%, 100% { transform: scale(1); filter: brightness(1); }
          50% { transform: scale(1.04); filter: brightness(1.15); }
        }
      `}</style>
    </div>
  );
}
