import { useEffect, useState } from "react";
import { site, nav, links, hero } from "@/config";
import Magnetic from "./Magnetic";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (href: string) => {
    setOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-[100] transition-all duration-500 ${
          scrolled
            ? "border-b border-white/[0.06] bg-[#07040d]/70 backdrop-blur-xl"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-10 md:py-5">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
            className="flex items-center gap-3"
            aria-label={site.name}
          >
            <img src={site.logo} alt={site.logoAlt} className="h-9 w-auto md:h-11" />
          </a>

          <nav className="hidden items-center gap-9 md:flex">
            {nav.map((n) => (
              <button
                key={n.href}
                onClick={() => go(n.href)}
                className="u-link font-mono2 text-[11px] uppercase tracking-[0.22em] text-[#c9c3d9] transition-colors hover:text-white"
              >
                {n.label}
              </button>
            ))}
          </nav>

          <div className="hidden md:block">
            <Magnetic strength={0.3}>
              <a
                href={links.messenger}
                target="_blank"
                rel="noreferrer"
                className="btn-cool inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#a855f7] px-6 py-2.5 text-sm font-semibold text-white transition-transform duration-300 active:scale-95"
              >
                {hero.primaryCta}
                <ArrowIcon />
              </a>
            </Magnetic>
          </div>

          {/* mobile hamburger */}
          <button
            className={`relative z-[130] flex h-11 w-11 flex-col items-center justify-center gap-[6px] md:hidden ${open ? "open" : ""}`}
            onClick={() => setOpen(!open)}
            aria-label="Menu"
          >
            <span
              className={`h-[2px] w-6 bg-white transition-all duration-300 ${open ? "translate-y-[8px] rotate-45" : ""}`}
            />
            <span className={`h-[2px] w-6 bg-white transition-all duration-300 ${open ? "opacity-0" : ""}`} />
            <span
              className={`h-[2px] w-6 bg-white transition-all duration-300 ${open ? "-translate-y-[8px] -rotate-45" : ""}`}
            />
          </button>
        </div>
      </header>

      {/* mobile fullscreen menu */}
      <div
        className={`fixed inset-0 z-[120] flex flex-col justify-between bg-[#0a0514]/95 px-8 pb-10 pt-28 backdrop-blur-2xl transition-all duration-500 md:hidden ${
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        <nav className="flex flex-col gap-2">
          {nav.map((n, i) => (
            <button
              key={n.href}
              onClick={() => go(n.href)}
              className={`border-b border-white/[0.07] py-5 text-left font-display text-4xl font-bold tracking-tight text-white transition-all duration-500 ${
                open ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
              }`}
              style={{ transitionDelay: open ? `${0.08 + i * 0.07}s` : "0s" }}
            >
              {n.label}
            </button>
          ))}
        </nav>
        <a
          href={links.messenger}
          target="_blank"
          rel="noreferrer"
          className={`flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#a855f7] px-6 py-4 text-base font-semibold text-white transition-all duration-500 ${
            open ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
          }`}
          style={{ transitionDelay: open ? "0.4s" : "0s" }}
        >
          {hero.primaryCta}
          <ArrowIcon />
        </a>
      </div>
    </>
  );
}

export function ArrowIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 17L17 7" />
      <path d="M8 7h9v9" />
    </svg>
  );
}
